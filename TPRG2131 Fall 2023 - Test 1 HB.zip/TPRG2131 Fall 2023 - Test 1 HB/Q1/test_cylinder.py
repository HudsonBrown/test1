from cylinder import volume_cylinder, area_cylinder
from pytest import raises

def test_volume_cylinder():
    flag = False
    assert round(volume_cylinder(1, 2), 4) == 1.5708
    assert round(volume_cylinder(0.1, 4), 6) == 0.031416
    assert round(volume_cylinder(2, 1), 4) == 3.1416
    with raises(ValueError):
        volume_cylinder(-1, -1) #I dont know why pytest fails this but not area
    
def test_area_cylinder():
    assert round(area_cylinder(1, 2), 4) == 7.8540
    assert round(area_cylinder(0.1, 4), 4) == 1.2723
    assert round(area_cylinder(2, 1), 4) == 12.5664
    with raises(ValueError):
        area_cylinder(-5, -5)